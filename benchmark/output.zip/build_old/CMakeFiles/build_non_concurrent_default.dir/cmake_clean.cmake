file(REMOVE_RECURSE
  "CMakeFiles/build_non_concurrent_default"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/build_non_concurrent_default.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
