# Empty compiler generated dependencies file for libbtree.
# This may be replaced when dependencies are built.
