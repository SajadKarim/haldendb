file(REMOVE_RECURSE
  "liblibbtree.a"
)
