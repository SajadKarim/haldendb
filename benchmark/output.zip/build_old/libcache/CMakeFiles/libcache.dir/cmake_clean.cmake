file(REMOVE_RECURSE
  "liblibcache.a"
  "liblibcache.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/libcache.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
