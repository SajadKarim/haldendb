file(REMOVE_RECURSE
  "liblibcache.a"
)
