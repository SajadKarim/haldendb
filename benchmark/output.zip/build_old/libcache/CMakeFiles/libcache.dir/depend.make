# Empty dependencies file for libcache.
# This may be replaced when dependencies are built.
